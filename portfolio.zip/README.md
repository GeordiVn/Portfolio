Deze repository gaat over mijn portfolio.
Hierin ga ik werken aan de eindopdracht voor het vak responsive design.
